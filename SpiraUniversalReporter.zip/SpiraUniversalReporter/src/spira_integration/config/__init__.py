"""Configuration management components."""
